   
function countLetters( ){ 
    var sentense = prompt("введите строку");
    var vowels = sentense.match(/[а, е, и, о, у, ы, э, ю, я]/igm).length;
    alert(vowels);        
}

 countLetters();