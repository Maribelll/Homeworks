var fio=prompt("Ваша фамилия, имя, отчество?");

 while (fio.length > 30) {
   var fio=prompt('Введите пожалуйста ФИО не длиннее 30 символов!');
 }
var age=prompt("Введите Ваш возраст");

 var ageValue = parseInt(age);


   while(isNaN(ageValue)){
      ageValue = prompt("введите корректную цифру");
    
   }
    while (ageValue==0) {
   ageValue= prompt("Введите цифру больше 0");
    }

var gender=prompt("Введите Ваш пол");
     while ("ж"!==gender||"м"!==gender)
       
     {
     gender = prompt("введите м или ж");
     }
     alert(fio + ' '+ age +' '+ gender);